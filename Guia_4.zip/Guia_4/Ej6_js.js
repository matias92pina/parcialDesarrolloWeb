function seleccionado(){
	var checkSeleccion = document.querySelector('input [name="rdoCalculos"]:checked');
	
	if (checkSeleccion != null)
		return 0;
	else
		return 1;
	
}

function calculos(x,y){
	var resultado;
	
	if (seleccionado()=='0'){
		x=Number(x);
		y=Number(y);
		var cuentas=getElementById(rdoCalculos).value;
		switch(cuentas){
			case "suma":
				resultado=x+y;
				break;
			case "resta":
				resultado=x-y;
				break;
			case "multi":
				resultado=x*y;
				break;
			case "div":
				resultado=x/y;
				break;
		}
		
		alert(resultado);
	}
	else{
		alert("Selecciona un calculo");
	}
}